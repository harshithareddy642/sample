#!/bin/bash
sudo chmod +x scripts/start_server.sh
sudo service httpd start

